
# UpperWest WebGIS Practical Pack


Contents:
1. Admin boundaries
2. Land records parcels
3. Urban planning roads
4. Health facilities
5. Agriculture zones
6. Hydrology river

Suggested exercises:
- qgis2web export to OpenLayers/Leaflet
- buffers
- styling and popups
- joins and filtering
- role-based layer separation
