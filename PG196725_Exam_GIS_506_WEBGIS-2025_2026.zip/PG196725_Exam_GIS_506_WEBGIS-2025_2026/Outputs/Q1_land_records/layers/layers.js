ol.proj.proj4.register(proj4);
//ol.proj.get("EPSG:4326").setExtent([-2.538489, 9.993705, -2.437689, 10.086380]);
var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_public_parcelparcels_1 = new ol.format.GeoJSON();
var features_public_parcelparcels_1 = format_public_parcelparcels_1.readFeatures(json_public_parcelparcels_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_public_parcelparcels_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_public_parcelparcels_1.addFeatures(features_public_parcelparcels_1);
var lyr_public_parcelparcels_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_public_parcelparcels_1, 
                style: style_public_parcelparcels_1,
                popuplayertitle: 'public_parcel — parcels',
                interactive: true,
                title: '<img src="styles/legend/public_parcelparcels_1.png" /> public_parcel — parcels'
            });

lyr_OpenStreetMap_0.setVisible(true);lyr_public_parcelparcels_1.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_public_parcelparcels_1];
lyr_public_parcelparcels_1.set('fieldAliases', {'fid': 'fid', 'parcel_id': 'parcel_id', 'owner': 'owner', 'status': 'status', });
lyr_public_parcelparcels_1.set('fieldImages', {'fid': '', 'parcel_id': '', 'owner': '', 'status': '', });
lyr_public_parcelparcels_1.set('fieldLabels', {'fid': 'no label', 'parcel_id': 'no label', 'owner': 'no label', 'status': 'no label', });
lyr_public_parcelparcels_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});