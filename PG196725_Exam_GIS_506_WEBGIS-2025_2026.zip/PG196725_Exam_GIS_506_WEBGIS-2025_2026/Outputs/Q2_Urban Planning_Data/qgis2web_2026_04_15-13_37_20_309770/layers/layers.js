ol.proj.proj4.register(proj4);
//ol.proj.get("EPSG:4326").setExtent([-2.564525, 9.984059, -2.396525, 10.138518]);
var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_exisiting_roadsroads_1 = new ol.format.GeoJSON();
var features_exisiting_roadsroads_1 = format_exisiting_roadsroads_1.readFeatures(json_exisiting_roadsroads_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_exisiting_roadsroads_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_exisiting_roadsroads_1.addFeatures(features_exisiting_roadsroads_1);
var lyr_exisiting_roadsroads_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_exisiting_roadsroads_1, 
                style: style_exisiting_roadsroads_1,
                popuplayertitle: 'exisiting_roads — roads',
                interactive: true,
                title: '<img src="styles/legend/exisiting_roadsroads_1.png" /> exisiting_roads — roads'
            });
var format_proposed_roadsroads_2 = new ol.format.GeoJSON();
var features_proposed_roadsroads_2 = format_proposed_roadsroads_2.readFeatures(json_proposed_roadsroads_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_proposed_roadsroads_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_proposed_roadsroads_2.addFeatures(features_proposed_roadsroads_2);
var lyr_proposed_roadsroads_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_proposed_roadsroads_2, 
                style: style_proposed_roadsroads_2,
                popuplayertitle: 'proposed_roads — roads',
                interactive: true,
                title: '<img src="styles/legend/proposed_roadsroads_2.png" /> proposed_roads — roads'
            });

lyr_OpenStreetMap_0.setVisible(true);lyr_exisiting_roadsroads_1.setVisible(true);lyr_proposed_roadsroads_2.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_exisiting_roadsroads_1,lyr_proposed_roadsroads_2];
lyr_exisiting_roadsroads_1.set('fieldAliases', {'fid': 'fid', 'name': 'name', 'type': 'type', });
lyr_proposed_roadsroads_2.set('fieldAliases', {'fid': 'fid', 'name': 'name', 'type': 'type', });
lyr_exisiting_roadsroads_1.set('fieldImages', {'fid': '', 'name': '', 'type': '', });
lyr_proposed_roadsroads_2.set('fieldImages', {'fid': '', 'name': '', 'type': '', });
lyr_exisiting_roadsroads_1.set('fieldLabels', {'fid': 'no label', 'name': 'no label', 'type': 'no label', });
lyr_proposed_roadsroads_2.set('fieldLabels', {'fid': 'inline label - always visible', 'name': 'inline label - always visible', 'type': 'inline label - always visible', });
lyr_proposed_roadsroads_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});