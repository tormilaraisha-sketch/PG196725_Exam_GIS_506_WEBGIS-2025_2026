var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_health_1 = new ol.format.GeoJSON();
var features_health_1 = format_health_1.readFeatures(json_health_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_health_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_health_1.addFeatures(features_health_1);
var lyr_health_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_health_1, 
                style: style_health_1,
                popuplayertitle: 'health',
                interactive: true,
    title: 'health<br />\
    <img src="styles/legend/health_1_0.png" /> Jirapa Hospital<br />\
    <img src="styles/legend/health_1_1.png" /> Lawra Clinic<br />\
    <img src="styles/legend/health_1_2.png" /> Tumu Hospital<br />' });

lyr_OpenStreetMap_0.setVisible(true);lyr_health_1.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_health_1];
lyr_health_1.set('fieldAliases', {'facility': 'facility', 'cases': 'cases', });
lyr_health_1.set('fieldImages', {'facility': '', 'cases': '', });
lyr_health_1.set('fieldLabels', {'facility': 'inline label - always visible', 'cases': 'inline label - always visible', });
lyr_health_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});